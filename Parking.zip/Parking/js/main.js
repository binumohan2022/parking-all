var scrollToTopBtn = document.querySelector(".back-to-top");
var rootElement = document.documentElement;

function handleScroll() {
    // Do something on scroll
    var scrollTotal = rootElement.scrollHeight - rootElement.clientHeight;
    if (rootElement.scrollTop / scrollTotal > 0.1) {
        // Show button
        scrollToTopBtn.classList.add("top-is-visible");
    } else {
        // Hide button
        scrollToTopBtn.classList.remove("top-is-visible");
    }
}

function scrollToTop() {
    // Scroll to top logic
    rootElement.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}
scrollToTopBtn.addEventListener("click", scrollToTop);
document.addEventListener("scroll", handleScroll);




$(document).ready(function() {    
    $(".addMore").on('click', function(e) {
        e.preventDefault();
        $(".moreShow:hidden").slice(0, 1).slideDown();
        if ($(".moreShow:hidden").length == 0) {
            $(".addMore").fadeOut('slow');
        }
    });
});